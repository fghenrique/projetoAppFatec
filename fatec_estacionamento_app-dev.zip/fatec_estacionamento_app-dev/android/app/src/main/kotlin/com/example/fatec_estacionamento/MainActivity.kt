package com.example.fatec_estacionamento

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
