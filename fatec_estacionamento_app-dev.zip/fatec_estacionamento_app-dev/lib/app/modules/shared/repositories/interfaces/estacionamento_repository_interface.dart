import 'package:flutter_modular/flutter_modular.dart';

abstract class IEstacionamentoRepository implements Disposable {
  Future get();
}
