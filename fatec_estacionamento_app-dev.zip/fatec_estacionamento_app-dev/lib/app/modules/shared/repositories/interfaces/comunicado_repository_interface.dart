import 'package:flutter_modular/flutter_modular.dart';

abstract class IComunicadoRepository implements Disposable {
  Future get();
}
