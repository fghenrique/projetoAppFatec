import 'package:flutter/material.dart';

class CustomColors {
  static Color azulEscuro = Color.fromRGBO(58, 84, 97, 1);
  static Color vinho = Color.fromRGBO(169, 16, 21, 1);
}
