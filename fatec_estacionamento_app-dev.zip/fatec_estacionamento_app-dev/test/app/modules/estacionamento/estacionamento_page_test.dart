import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('EstacionamentoPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(EstacionamentoPage(title: 'Estacionamento')));
    //  final titleFinder = find.text('Estacionamento');
    //  expect(titleFinder, findsOneWidget);
  });
}
