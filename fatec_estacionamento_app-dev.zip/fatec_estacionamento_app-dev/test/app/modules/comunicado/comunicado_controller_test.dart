import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:fatec_estacionamento/app/modules/comunicado/comunicado_module.dart';

void main() {
  initModule(ComunicadoModule());
  // ComunicadoController comunicado;
  //
  setUp(() {
    //     comunicado = ComunicadoModule.to.get<ComunicadoController>();
  });

  group('ComunicadoController Test', () {
    //   test("First Test", () {
    //     expect(comunicado, isInstanceOf<ComunicadoController>());
    //   });

    //   test("Set Value", () {
    //     expect(comunicado.value, equals(0));
    //     comunicado.increment();
    //     expect(comunicado.value, equals(1));
    //   });
  });
}
