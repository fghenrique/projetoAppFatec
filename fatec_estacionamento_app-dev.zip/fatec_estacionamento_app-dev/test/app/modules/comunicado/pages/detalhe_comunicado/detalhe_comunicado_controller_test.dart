import 'package:flutter_modular/flutter_modular_test.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:fatec_estacionamento/app/modules/comunicado/comunicado_module.dart';

void main() {
  initModule(ComunicadoModule());
  // DetalheComunicadoController detalhecomunicado;
  //
  setUp(() {
    //     detalhecomunicado = ComunicadoModule.to.get<DetalheComunicadoController>();
  });

  group('DetalheComunicadoController Test', () {
    //   test("First Test", () {
    //     expect(detalhecomunicado, isInstanceOf<DetalheComunicadoController>());
    //   });

    //   test("Set Value", () {
    //     expect(detalhecomunicado.value, equals(0));
    //     detalhecomunicado.increment();
    //     expect(detalhecomunicado.value, equals(1));
    //   });
  });
}
