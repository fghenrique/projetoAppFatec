import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('DetalheComunicadoPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(DetalheComunicadoPage(title: 'DetalheComunicado')));
    //  final titleFinder = find.text('DetalheComunicado');
    //  expect(titleFinder, findsOneWidget);
  });
}
