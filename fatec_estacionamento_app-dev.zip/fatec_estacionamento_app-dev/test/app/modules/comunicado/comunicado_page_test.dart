import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('ComunicadoPage has title', (tester) async {
    //  await tester.pumpWidget(buildTestableWidget(ComunicadoPage(title: 'Comunicado')));
    //  final titleFinder = find.text('Comunicado');
    //  expect(titleFinder, findsOneWidget);
  });
}
