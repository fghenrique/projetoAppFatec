import 'package:flutter_test/flutter_test.dart';

void main() {
  //SharedPreferencesLocalDbService service;

  setUp(() {
//    service = SharedPreferencesLocalDbService();
  });
//
  group('SharedPreferencesLocalDbService Test', () {
//    test("First Test", () {
//      expect(service, isInstanceOf<SharedPreferencesLocalDbService>());
//    });
//
  });
}
